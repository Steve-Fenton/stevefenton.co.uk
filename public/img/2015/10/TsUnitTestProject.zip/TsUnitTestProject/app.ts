﻿/// <reference="references.ts" />

import * as tsUnit from 'tsUnit';
import * as MyClassTests from 'MyClassTests';

window.onload = () =>
{
    var el = document.getElementById('results');

    var test = new tsUnit.Test(MyClassTests);
    var result = test.run().showResults(el);

    console.log(result.getTapResults());
};
