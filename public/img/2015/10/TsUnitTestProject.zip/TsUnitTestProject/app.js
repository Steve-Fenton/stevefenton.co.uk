/// <reference="references.ts" />
define(["require", "exports", 'tsUnit', 'MyClassTests'], function (require, exports, tsUnit, MyClassTests) {
    window.onload = function () {
        var el = document.getElementById('results');
        var test = new tsUnit.Test(MyClassTests);
        var result = test.run().showResults(el);
        console.log(result.getTapResults());
    };
});
//# sourceMappingURL=app.js.map