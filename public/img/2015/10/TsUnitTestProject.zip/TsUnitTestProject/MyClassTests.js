var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", 'tsUnit', 'MyClass'], function (require, exports, tsUnit, MyModule) {
    // This means you can just use MyClass in your code, rather than the full MyModule.MyClass.
    var MyClass = MyModule.MyClass;
    var MyClassTests = (function (_super) {
        __extends(MyClassTests, _super);
        function MyClassTests() {
            _super.apply(this, arguments);
        }
        MyClassTests.prototype.someTest = function () {
            var v = new MyClass(1, 2);
            this.areIdentical(v.getSum(), 3);
        };
        return MyClassTests;
    })(tsUnit.TestClass);
    exports.MyClassTests = MyClassTests;
});
//# sourceMappingURL=MyClassTests.js.map