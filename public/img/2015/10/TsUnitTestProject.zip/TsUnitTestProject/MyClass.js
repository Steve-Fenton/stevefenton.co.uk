define(["require", "exports"], function (require, exports) {
    var MyClass = (function () {
        function MyClass(num1, num2) {
            this.num1_ = num1;
            this.num2_ = num2;
        }
        MyClass.prototype.getSum = function () {
            return this.num1_ + this.num2_;
        };
        return MyClass;
    })();
    exports.MyClass = MyClass;
});
//# sourceMappingURL=MyClass.js.map