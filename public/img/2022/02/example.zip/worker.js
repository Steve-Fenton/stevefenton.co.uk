const run = function () {
    // GIVE ME SOME CODE!
};

chrome.action.onClicked.addListener((tab) => {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: run
    });
  });